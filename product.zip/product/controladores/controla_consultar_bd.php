<?php

// paso 1 importar o llamar la conexion a la BD/DB
require "../config/conexion.php";

//paso 2 Captura variables
// NO HAY VARIABLES

//paso 3 sentencia sql
$sql = "SELECT 
id, nombre, documento, create_ad
FROM 
usuarios 
WHERE 1";

//paso 4
forceach($dbh->query($sql) as $row)
{
    echo"nombre= ".$row [1]." - documento = ".$row['documento']."<br>";
}
