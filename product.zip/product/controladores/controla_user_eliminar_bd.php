<?php

// paso 1 importar o llamar la conexion a la BD/DB
require "../config/conexion.php";

//paso 2 Captura variables
$documento = $_POST["documento"];

//paso 3
$sql = "DELETE FROM usuarios 
WHERE documento = '".$documento."";

//paso 4 Ejecutar el sql
if($dbh->query($sql))
{
  echo "usuario eliminado correctamente";
}else
{
  echo"error";
}
?> 