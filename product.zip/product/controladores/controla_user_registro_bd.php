<?php
//paso1
//importar o llamar la conexion a la BD/DB
require "../config/conexion.php";

//Captura variables
$nombre = $_POST["nombre"];
$documento = $_POST["documento"];

//paso 3 setencia sql
$sql = "INSERT INTO usuarios
(nombre, documento, create_ad) 
VALUES 
('".$nombre."', '".$documento."', now())"; 

//paso 4 Ejecutar el sql
if($dbh->query($sql))
{
  echo "usuario registrado correctamente";
}else
{
  echo"error";
}
?> 