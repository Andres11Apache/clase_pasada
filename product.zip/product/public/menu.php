</a></li>
          <li class="nav-item"><a class="nav-link" href="registro.php">Registrar usuario</a></li>
          <li class="nav-item"><a class="nav-link" href="consultar.php">Consultar usuario</a></li>
          <li class="nav-item"><a class="nav-link" href="editar.php">Editar usuario</a></li>
          <li class="nav-item"><a class="nav-link" href="eliminar.php">Eliminar usuario</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Support</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Pricing</a></li>
          <li class="nav-item"><a class="nav-link" href="#">
            <svg class="bi" width="24" height="24"><use xlink:href="#cart"/></svg>
          </a></li>